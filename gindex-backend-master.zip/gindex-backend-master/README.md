# gindex-backend
Backend for gindex for Maintaining User Database

##### without this the Main GIndex wont work, Both should run simultaneously.

#### Deploy to Heroku Directly:
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https%3A%2F%2Fgithub.com%2Ftks18%2Fgindex-backend%2Ftree%2Fmaster)
